package com.ty.hospital.hospitalappboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalAppBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
